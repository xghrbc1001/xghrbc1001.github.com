#!/bin/bash

now=`date +%Y%m%d%H%M%S`
JAVA_HOME=/data/jdk1.6.0_29
jmap_cmd="$JAVA_HOME/bin/jmap"

pid=`ps aux | grep '/data/baike/apache' | grep -v grep | head -1 | awk '{print $2}'`
$jmap_cmd -histo $pid > ./javamap/jmap$now.txt
