#!/bin/bash

now=`date +%Y%m%d%H%M%S`
JAVA_HOME=/data/jdk1.6.0_29
jstack_cmd="$JAVA_HOME/bin/jstack"

pid=`ps aux | grep '/data/baike/apache' | grep -v grep | head -1 | awk '{print $2}'`
$jstack_cmd $pid > ./javastack/jstack$now.txt
