#!/bin/bash
JAVA_HOME=/data/jdk1.6.0_29

PID=$($JAVA_HOME/bin/jps|grep Bootstrap|awk '{print $1}')
$JAVA_HOME/bin/jstat -gc $PID 1000
